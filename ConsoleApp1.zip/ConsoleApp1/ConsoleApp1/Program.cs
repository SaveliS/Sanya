﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        
    }
    class Point
    {
        public double x;
        public double y;

        public Point()
        {
        }

        public Point(double a, double b)
        {
            x = a;
            y = b;
        }

        public static Point Write(Point A)
        {
            Console.WriteLine(A.x);
            Console.WriteLine(A.y);
            return A;
        }
        public static Point Coordinate(Point A, double a, double b)
        {
            A.x = a;
            A.y = b;
            Point.Write(A);
            return A;
        }
    }
    class Line : Point
    {
        public Point A;
        public Point B;

        public Line()
        {
        }

        public Line(Point A, Point B)
        {
        }

        public static Line Write(Line C)
        {
            if ((C.A.x == null) || (C.B.x == null) || (C.A.y == null) || (C.B.y == null))
            {
                return null;
            }
            else
            {
                Console.WriteLine(C.A.x);
                Console.WriteLine(C.A.y);
                Console.WriteLine(C.B.x);
                Console.WriteLine(C.B.y);
                return C;
            }
        }
    }
}
